public class FailException extends Exception {
	public FailException(String message) {
		super(message);
	}
}
