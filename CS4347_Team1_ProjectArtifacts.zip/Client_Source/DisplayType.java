interface DisplayType {
	void display();
}
